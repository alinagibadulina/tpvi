﻿namespace ASPA0011_1.Models;

public class ElementDto
{
    public Guid Id { get; set; }
    public string? Data { get; set; } // JSON-string payload
}
