﻿namespace ASPA0011_1.Models;

public class ChannelDto
{
    public Guid Id { get; set; }
    public string? Name { get; set; }
    public string? State { get; set; } // "CLOSED" | "ACTIVE"
    public string? Description { get; set; }
}
