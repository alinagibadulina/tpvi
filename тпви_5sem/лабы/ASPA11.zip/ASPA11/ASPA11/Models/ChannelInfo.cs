namespace ASPA11.Models
{
    public record ChannelInfo
(
    Guid Id,
    string Name,
    string State,
    string Description,
    int Count
);
}
