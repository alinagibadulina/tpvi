﻿namespace ASPA0011_1.Models;

public class CreateChannelRequest
{
    public string? Command { get; set; } // "new"
    public string? Name { get; set; }
    public string? State { get; set; } // "ACTIVE" or "CLOSED"
    public string? Description { get; set; }
}

public class ChannelCommandRequest
{
    public string? Command { get; set; } // "close","open","del"
    public Guid? Id { get; set; }        // optional for global commands
    public string? State { get; set; }   // optional state
    public string? Reason { get; set; }  // optional
}

public class QueueRequest
{
    public string? Command { get; set; } // "dequeue","peek","enqueue"
    public Guid? Id { get; set; }        // id of channel
    public string? Data { get; set; }    // for enqueue: JSON-string
}

public class DeleteChannelsRequest
{
    public string Command { get; set; } = "";
    public string? Status { get; set; } // CLOSED или null
}

