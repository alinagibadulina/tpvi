﻿using Microsoft.Extensions.Logging;

namespace ASPA0011_1.Logging;

public class FileLoggerProvider : ILoggerProvider
{
    private readonly string _path;
    private readonly IWebHostEnvironment _env;

    public FileLoggerProvider(string path, IWebHostEnvironment env)
    {
        _path = path;
        _env = env;
    }

    public ILogger CreateLogger(string categoryName)
        => new FileLogger(_path, _env);

    public void Dispose() { }
}
public class FileLogger : ILogger
{
    private readonly string _path;
    private readonly IWebHostEnvironment _env;

    public FileLogger(string path, IWebHostEnvironment env)
    {
        _path = path;
        _env = env;
    }

    public IDisposable BeginScope<TState>(TState state) => default!;

    public bool IsEnabled(LogLevel logLevel) => true;

    public void Log<TState>(
        LogLevel logLevel,
        EventId eventId,
        TState state,
        Exception? exception,
        Func<TState, Exception?, string> formatter)
    {

        if (!_env.IsDevelopment() &&
            (logLevel == LogLevel.Trace || logLevel == LogLevel.Debug))
            return;

        var msg =
            $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {logLevel}: {formatter(state, exception)}";

        Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
        File.AppendAllText(_path, msg + Environment.NewLine);
    }
}