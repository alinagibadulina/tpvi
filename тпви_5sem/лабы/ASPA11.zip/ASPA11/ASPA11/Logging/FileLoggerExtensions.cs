﻿using Microsoft.Extensions.Logging;

namespace ASPA0011_1.Logging;

public static class FileLoggerExtensions
{
    public static ILoggingBuilder AddFile(this ILoggingBuilder builder, string filepath, IWebHostEnvironment env)
    {
        builder.AddProvider(new FileLoggerProvider(filepath, env));
        return builder;
    }
}
