﻿using ASPA0011_1.Models;
using ASPA11.Models;
using System.Collections.Concurrent;
using System.Threading.Channels;

namespace ASPA0011_1.Services;

public class ChannelService
{
    private readonly ConcurrentDictionary<Guid, ChannelWrapper> _channels = new();
    private readonly ILogger<ChannelService> _logger;
    private readonly int _waitEnqueueSeconds;

    private int _eventCounter = 1;
    private EventId NextEvent => new EventId(_eventCounter++);

    public ChannelService(IConfiguration config, ILogger<ChannelService> logger)
    {
        _logger = logger;
        _waitEnqueueSeconds = config.GetValue<int?>("WaitEnqueue") ?? 5;

        _logger.LogInformation(
            NextEvent,
            "ChannelService initialized. WaitEnqueue={Wait}s",
            _waitEnqueueSeconds
        );
    }

    public IEnumerable<ChannelDto> GetAll()
    {
        _logger.LogTrace(NextEvent, "GetAll called");
        return _channels.Values.Select(c =>
            new ChannelDto { Id = c.Id, Name = c.Name, State = c.State, Description = c.Description });
    }

    public ChannelWrapper? Get(Guid id)
    {
        _logger.LogTrace(NextEvent, "Get called for Id={Id}", id);
        return _channels.TryGetValue(id, out var ch) ? ch : null;
    }

    public ChannelDto Create(CreateChannelRequest req)
    {
        _logger.LogTrace(
            NextEvent,
            "CreateChannel called with Name='{Name}', State='{State}', Description='{Desc}'",
            req.Name, req.State, req.Description
        );

        var ch = new ChannelWrapper
        {
            Name = req.Name,
            State = req.State ?? "ACTIVE",
            Description = req.Description
        };

        _channels[ch.Id] = ch;

        _logger.LogInformation(
            NextEvent,
            "Channel created: Id={Id}, Name='{Name}', State={State}",
            ch.Id, ch.Name, ch.State
        );

        return new ChannelDto
        {
            Id = ch.Id,
            Name = ch.Name,
            State = ch.State,
            Description = ch.Description
        };
    }

    public IEnumerable<ChannelInfo> DeleteAll()
    {
        var removed = new List<ChannelInfo>();

        foreach (var c in _channels.Values.ToList())
        {
            _channels.TryRemove(c.Id, out _);
            removed.Add(new ChannelInfo(c.Id, c.Name, c.State, c.Description, 0));
        }

        _logger.LogInformation(NextEvent, "All channels deleted");

        return removed;
    }

    public IEnumerable<ChannelInfo> DeleteClosed()
    {
        var removed = new List<ChannelInfo>();

        foreach (var c in _channels.Values.Where(x => x.State == "CLOSED").ToList())
        {
            _channels.TryRemove(c.Id, out _);
            removed.Add(new ChannelInfo(c.Id, c.Name, c.State, c.Description, 0));
        }

        _logger.LogInformation(NextEvent, "All CLOSED channels deleted");

        return removed;
    }

    public IEnumerable<ChannelDto> ModifyAll(ChannelCommandRequest req)
    {
        _logger.LogTrace(NextEvent, "ModifyAll called: Command={Cmd}", req.Command);

        foreach (var ch in _channels.Values)
        {
            if (req.Command == "close") ch.State = "CLOSED";
            else if (req.Command == "open") ch.State = "ACTIVE";
        }

        _logger.LogInformation(
            NextEvent,
            "ModifyAll executed: {Cmd}",
            req.Command
        );

        return GetAll();
    }

    public ChannelDto? ModifyOne(ChannelCommandRequest req)
    {
        if (req.Id == null)
        {
            _logger.LogWarning(NextEvent, "ModifyOne called without Id");
            return null;
        }

        if (!_channels.TryGetValue(req.Id.Value, out var ch))
        {
            _logger.LogWarning(NextEvent, "ModifyOne: channel not found Id={Id}", req.Id);
            return null;
        }

        if (req.Command == "close") ch.State = "CLOSED";
        else if (req.Command == "open") ch.State = "ACTIVE";

        _logger.LogInformation(
            NextEvent,
            "ModifyOne executed: Id={Id}, Command={Cmd}",
            ch.Id, req.Command
        );

        return new ChannelDto { Id = ch.Id, Name = ch.Name, State = ch.State, Description = ch.Description };
    }

    public (ChannelDto? removed, bool ok) Delete(ChannelCommandRequest req)
    {
        if (req.Id == null)
        {
            _logger.LogWarning(NextEvent, "Delete called without Id");
            return (null, false);
        }

        if (_channels.TryRemove(req.Id.Value, out var ch))
        {
            _logger.LogInformation(NextEvent, "Channel deleted: Id={Id}", ch.Id);

            return (
                new ChannelDto
                {
                    Id = ch.Id,
                    Name = ch.Name,
                    State = ch.State,
                    Description = ch.Description
                },
                true
            );
        }

        _logger.LogWarning(NextEvent, "Delete failed: channel not found Id={Id}", req.Id);
        return (null, false);
    }

    public async Task<object> QueueOperationAsync(QueueRequest req)
    {
        if (req.Id == null)
        {
            _logger.LogError(NextEvent, "Queue operation: missing Channel Id");
            return new { id = Guid.Empty, error = "Channel id missing" };
        }

        if (!_channels.TryGetValue(req.Id.Value, out var ch))
        {
            _logger.LogWarning(NextEvent, "Queue op on non-existing channel Id={Id}", req.Id);
            return new { id = req.Id, error = "Channel not found" };
        }

        var writer = ch.Channel.Writer;
        var reader = ch.Channel.Reader;

        switch (req.Command)
        {
            case "enqueue":
                _logger.LogTrace(NextEvent, "EnqueueAsync called Id={Id}, Data='{Data}'", ch.Id, req.Data);

                if (ch.State != "ACTIVE")
                {
                    _logger.LogWarning(NextEvent, "Enqueue on CLOSED channel Id={Id}", ch.Id);
                    return new { id = ch.Id, error = "Channel closed" };
                }

                using (var cts = new CancellationTokenSource(TimeSpan.FromSeconds(_waitEnqueueSeconds)))
                {
                    try
                    {
                        if (await writer.WaitToWriteAsync(cts.Token))
                        {
                            writer.TryWrite(req.Data ?? "");
                            _logger.LogDebug(NextEvent, "Data enqueued to Id={Id}", ch.Id);
                            return new { id = ch.Id, status = "enqueued" };
                        }
                        else
                        {
                            _logger.LogWarning(NextEvent, "WaitEnqueue timeout Id={Id}", ch.Id);
                            return new { id = ch.Id, error = "WaitEnqueue timeout" };
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        _logger.LogWarning(NextEvent, "WaitEnqueue canceled Id={Id}", ch.Id);
                        return new { id = ch.Id, error = "WaitEnqueue timeout" };
                    }
                }

            case "dequeue":
                _logger.LogTrace(NextEvent, "DequeueAsync called Id={Id}", ch.Id);

                if (reader.TryRead(out var item))
                {
                    _logger.LogDebug(NextEvent, "Dequeued Id={Id}, Data='{Data}'", ch.Id, item);
                    return new ElementDto { Id = ch.Id, Data = item };
                }
                else
                {
                    _logger.LogTrace(NextEvent, "Dequeue empty Id={Id}", ch.Id);
                    return new { id = ch.Id, status = "empty" };
                }

            case "peek":
                _logger.LogTrace(NextEvent, "PeekAsync called Id={Id}", ch.Id);

                var tmp = new List<string>();
                while (reader.TryRead(out var it)) tmp.Add(it);

                if (!tmp.Any())
                {
                    _logger.LogTrace(NextEvent, "Peek empty Id={Id}", ch.Id);
                    return new { id = ch.Id, status = "empty" };
                }

                foreach (var t in tmp) writer.TryWrite(t);

                _logger.LogDebug(NextEvent, "Peek Id={Id}, Data='{Data}'", ch.Id, tmp.First());
                return new ElementDto { Id = ch.Id, Data = tmp.First() };

            default:
                _logger.LogError(NextEvent, "Invalid queue command '{Cmd}' for Id={Id}", req.Command, ch.Id);
                return new { id = ch.Id, error = "invalid command" };
        }
    }
}
