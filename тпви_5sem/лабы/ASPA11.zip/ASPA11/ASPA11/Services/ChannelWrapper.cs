﻿using System.Threading.Channels;

namespace ASPA0011_1.Services;
using System.Threading.Channels;

public class ChannelWrapper
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public string State { get; set; } = "ACTIVE";
    public string? Name { get; set; }
    public string? Description { get; set; }

    public Channel<string> Channel { get; private set; }

    public ChannelWrapper()
    {
        Channel = System.Threading.Channels.Channel.CreateUnbounded<string>();
    }
}
