﻿using ASPA0011_1.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace ASPA0011_1.Controllers;

public class HomeController : Controller
{
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        var model = new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier };
        return View(model);
    }

    public IActionResult Index()
    {
        // simple page telling this app is API + MVC
        return Content("ASPA0011_1 — API + MVC (use Postman to test).");
    }
}
