﻿using ASPA0011_1.Models;
using ASPA0011_1.Services;
using Microsoft.AspNetCore.Mvc;

namespace ASPA0011_1.Controllers;

[ApiController]
[Route("api/queue")]
public class QueueController : ControllerBase
{
    private readonly ChannelService _service;
    public QueueController(ChannelService service) => _service = service;

    [HttpPost]
    public async Task<IActionResult> Operate([FromBody] QueueRequest req)
    {
        var res = await _service.QueueOperationAsync(req);

        // standardized 404 check: if returned object has error "Channel not found"
        if (res is IDictionary<string, object> dict && dict.ContainsKey("error") && dict["error"]?.ToString() == "Channel not found")
            return NotFound(res);

        return Ok(res);
    }
}
