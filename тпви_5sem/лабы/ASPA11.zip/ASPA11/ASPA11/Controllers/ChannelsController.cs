using ASPA0011_1.Models;
using ASPA0011_1.Services;
using Microsoft.AspNetCore.Mvc;

namespace ASPA0011_1.Controllers;

[ApiController]
[Route("api/channels")]
public class ChannelsController : ControllerBase
{
    private readonly ChannelService _service;
    public ChannelsController(ChannelService service) => _service = service;

    [HttpGet]
    public IActionResult GetAll()
    {
        var list = _service.GetAll().ToList();
        return list.Any() ? Ok(list) : NoContent();
    }

    [HttpGet("{id:guid}")]
    public IActionResult Get(Guid id)
    {
        var ch = _service.Get(id);
        return ch == null ? NotFound(new { id, error = "not found" }) : Ok(new ChannelDto { Id = ch.Id, Name = ch.Name, State = ch.State, Description = ch.Description });
    }

    [HttpPost]
    public IActionResult Create([FromBody] CreateChannelRequest req)
    {
        if (req == null) return BadRequest();
        var dto = _service.Create(req);
        return dto.State == "ACTIVE" ? Created($"/api/channels/{dto.Id}", dto) : NoContent();
    }

    [HttpPut]
    public IActionResult ModifyAll([FromBody] ChannelCommandRequest req)
    {
        var result = _service.ModifyAll(req);
        return Ok(result);
    }

    [HttpDelete]
    [HttpDelete]
    public IActionResult Delete(DeleteChannelsRequest req)
    {
        if (req.Command != "del")
            return BadRequest("Unknown command");

        if (req.Status == null)
        {
            var removed = _service.DeleteAll();
            return Ok(removed);
        }

        if (req.Status == "CLOSED")
        {
            var removed = _service.DeleteClosed();
            return Ok(removed);
        }

        return BadRequest("Unknown status");
    }


    [HttpPut("item")]
    public IActionResult ModifyOne([FromBody] ChannelCommandRequest req)
    {
        var dto = _service.ModifyOne(req);
        if (dto == null) return NotFound(new { error = "not found" });
        return Ok(dto);
    }
}
