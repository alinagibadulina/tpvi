﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BSTU.Results.Collection.Models
{
    public class ResultItem
    {
        public int Id { get; set; }
        public string Value { get; set; } = string.Empty;
    }
}
