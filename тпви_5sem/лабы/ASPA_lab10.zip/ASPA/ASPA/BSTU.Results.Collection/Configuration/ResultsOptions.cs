﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BSTU.Results.Collection.Configuration
{
    public class ResultsOptions
    {
        public string FilePath { get; set; } = "results.json";
    }
}