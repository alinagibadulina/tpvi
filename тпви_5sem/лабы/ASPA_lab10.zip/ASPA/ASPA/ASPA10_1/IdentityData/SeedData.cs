﻿using Microsoft.AspNetCore.Identity;

namespace ASPA0010_1.IdentityData
{
    public static class SeedData
    {
        public static async Task SeedDataAsync(IServiceProvider serviceProvider)
        {
            var roleMgr = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            var userMgr = serviceProvider.GetRequiredService<UserManager<IdentityUser>>();

            var roles = new[] { "READER", "WRITER" };
            foreach (var role in roles)
            {
                if (!await roleMgr.RoleExistsAsync(role))
                    await roleMgr.CreateAsync(new IdentityRole(role));
            }

            var readerUser = new IdentityUser { UserName = "reader1" };
            if (await userMgr.FindByNameAsync(readerUser.UserName) == null)
                await userMgr.CreateAsync(readerUser, "Reader@123");
            if (!await userMgr.IsInRoleAsync(readerUser, "READER"))
                await userMgr.AddToRoleAsync(readerUser, "READER");

            var writerUser = new IdentityUser { UserName = "writer1" };
            if (await userMgr.FindByNameAsync(writerUser.UserName) == null)
                await userMgr.CreateAsync(writerUser, "Writer@123");
            if (!await userMgr.IsInRoleAsync(writerUser, "WRITER"))
                await userMgr.AddToRoleAsync(writerUser, "WRITER");
        }
    }

}
