﻿namespace ASPA006_1
{
    public class CelebritiesConfig
    {
        public string PhotoFolder { get; set; }
        public string ConnectionString { get; set; }
    }
}
