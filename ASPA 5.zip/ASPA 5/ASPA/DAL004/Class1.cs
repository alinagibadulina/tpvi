﻿using System.Collections.Generic;
using System.IO;
using System.Reflection.Metadata.Ecma335;
using Newtonsoft.Json;
using System.Reflection;
using System.Text.Json;
using System;
namespace DAL004
{
    public class UpdateCelebrityException : Exception
    {
        public UpdateCelebrityException(string message) : base($"UpdateCelebrity error: {message}") { }
    }
    public class DeleteCelebrityException : Exception
    {
        public DeleteCelebrityException(string message) : base($"DeleteCelebrity error: {message}") { }

    }
    public class FoundByIdException : Exception
    {
        public FoundByIdException(string message) : base($"Found by Id: {message}") { }
    };
    public class SaveException : Exception
    {
        public SaveException(string message) : base($"SaveChanges error:{message}") { }
    };
    public class AddCelebrityException : Exception
    {
        public AddCelebrityException(string message) : base($"AddCelebrityException error: {message}") { }
    };
    public interface IRepository : IDisposable
    {
        string BasePath { get; }
        Celebrity[] getAllCelebrities();
        Celebrity? getCelebrityById(int id);

        Celebrity[] getCelebritiesBySurname(string name);

        string? getPhotoPathId(int id);
        int? addCelebrity(Celebrity celebrity);
        bool delCelebrityById(int Id);
        int? updCelebrityById(int Id, Celebrity celebrity);
        int SaveChanges();
    }

    public record Celebrity(int Id, string Firstname, string Surname, string PhotoPath);
    public class Repository : IRepository
    {
        public static string? JSONFileName { get; set; }

        public string BasePath { get; }

        public Celebrity[] _celebrities;

        public Repository(string basePath)
        {

            BasePath = Path.Combine(@"C:\УНИВЕР\трви\ASPA\ASPA\DAL004", basePath);
            string jsonPath = Path.Combine(BasePath, JSONFileName);
            if (File.Exists(jsonPath))
            {
                string jsonData = File.ReadAllText(jsonPath);
                _celebrities = System.Text.Json.JsonSerializer.Deserialize<Celebrity[]>(jsonData) ?? Array.Empty<Celebrity>();
                Console.WriteLine("данные получены");
            }
            else
            {
                _celebrities = Array.Empty<Celebrity>();
                Console.WriteLine("данных нет");
            }
        }
        public Celebrity? getCelebrityById(int id) => _celebrities.FirstOrDefault(c => c.Id == id);

        public Celebrity[] getAllCelebrities() => _celebrities;

        public Celebrity[] getCelebritiesBySurname(string surname) => _celebrities.Where(c => c.Surname == surname).ToArray();
        public string? getPhotoPathId(int id) => _celebrities.Where(c => c.Id == id).FirstOrDefault()?.PhotoPath;
      


    public int? addCelebrity(Celebrity celebrity)
        {
            if (celebrity == null)
            {
                throw new Exception("Celebrity cannot be null");
            }

            if (string.IsNullOrWhiteSpace(celebrity.Firstname) || string.IsNullOrWhiteSpace(celebrity.Surname))
            {
                throw new Exception("First name and surname are required");
            }

            //if (_celebrities.Any(c => c.Id == celebrity.Id))
            //{
            //    throw new Exception("Celebrity with this ID already exists");
            //}
            if (string.IsNullOrWhiteSpace(celebrity.PhotoPath) )// !File.Exists(celebrity.PhotoPath))
            {
                throw new Exception("Invalid photo path");
            }

            int newId = _celebrities.Length > 0 ? _celebrities.Max(c => c.Id) + 1 : 1;

            var newCelebrity = celebrity with { Id = newId };

            var newArrayOfCelebrities = _celebrities.Append(newCelebrity).ToArray();
            _celebrities = newArrayOfCelebrities;

            return newCelebrity.Id;
        }
        public bool delCelebrityById(int Id)
        {
            var celebrityToDelete = _celebrities.FirstOrDefault(c => c.Id == Id);
            if (celebrityToDelete == null)
            {
                return false;
            }

            _celebrities = _celebrities.Where(_c => _c.Id != Id).ToArray();
            return true;
           
        }

        public int? updCelebrityById(int Id, Celebrity celebrity)
        {
            var celebrityToChange = _celebrities.FirstOrDefault(c => c.Id == Id);
            if (celebrityToChange == null)
            {
                return 1;
            }
            _celebrities[_celebrities.ToList().IndexOf(celebrityToChange)]   = celebrity;
            return celebrityToChange.Id;

        }
        public int SaveChanges() {
           
            string jsonPath = Path.Combine(@"C:\УНИВЕР\трви\ASPA\ASPA\DAL004\Celebrities", JSONFileName);
            if (File.Exists(jsonPath))
            {
                var serCeleb = System.Text.Json.JsonSerializer.Serialize(_celebrities);
               File.WriteAllText(jsonPath,serCeleb);
                Console.WriteLine("данные сохранены");
                return _celebrities.Length;
            }
            else
            {
                Console.WriteLine("данные не сохранены");
                return 0;
            }
               }
        public void Dispose()
        {
        }
    }
}
