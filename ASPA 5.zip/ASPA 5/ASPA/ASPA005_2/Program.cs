using DAL004;
using Microsoft.AspNetCore.Diagnostics;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        builder.Services.AddScoped<IRepository>(provider =>
        {
            Repository.JSONFileName = "Celebrities.json";
            return new Repository("Celebrities");
        });

        builder.Services.AddScoped<SurnameFilter>();
        builder.Services.AddScoped<PhotoExistFilter>();
        builder.Services.AddScoped<UpdateFilter>();
        builder.Services.AddScoped<DeleteFilter>();

        var app = builder.Build();

        app.UseExceptionHandler("/Celebrities/Error");

        RouteGroupBuilder api = app.MapGroup("/Celebrities");

        api.MapGet("/", (IRepository repository) => repository.getAllCelebrities());

        api.MapGet("/{id:int}", (int id, IRepository repository) =>
        {
            Celebrity? celebrity = repository.getCelebrityById(id);
            if (celebrity == null)
            {
                throw new FoundByIdException($"Celebrity Id = {id}");
            }
            return celebrity;
        });

        api.MapPost("/", (Celebrity celebrity, IRepository repository) =>
        {
            int? id = repository.addCelebrity(celebrity);
            if (id == null) throw new AddCelebrityException("POST /Celebrities error, id == null");
            if (repository.SaveChanges() <= 0) throw new SaveException("/Celebrities error, SaveChanges() <= 0");
            return new Celebrity((int)id, celebrity.Firstname, celebrity.Surname, celebrity.PhotoPath);
        })
        .AddEndpointFilter<SurnameFilter>()
        .AddEndpointFilter<PhotoExistFilter>();

        api.MapDelete("/{id:int}", (int id, IRepository repository) =>
        {
            if (!repository.delCelebrityById(id))
            {
                throw new DeleteCelebrityException($"Delete by Id:DELETE /Celebrities error, Id = {id}");
            }
            if (repository.SaveChanges() <= 0) throw new SaveException("/Celebrities error, SaveChanges() <= 0");
            return $"Celebrity with Id = {id} deleted";
        })
        .AddEndpointFilter<DeleteFilter>();

        api.MapPut("/{id:int}", (int id, Celebrity celebrity, IRepository repository) =>
        {
            int? Id = repository.updCelebrityById(id, celebrity);
            if (Id == null) throw new UpdateCelebrityException("Put /Celebrities error, id == null");
            if (repository.SaveChanges() <= 0) throw new SaveException("/Celebrities error, SaveChanges() <= 0");
            return new Celebrity((int)Id, celebrity.Firstname, celebrity.Surname, celebrity.PhotoPath);
        })
        .AddEndpointFilter<UpdateFilter>();

        app.Map("/Celebrities/Error", (HttpContext ctx) =>
        {
            Exception? ex = ctx.Features.Get<IExceptionHandlerFeature>()?.Error;
            IResult rc = Results.Problem(
                detail: "Internal server error",
                instance: app.Environment.EnvironmentName,
                title: "ASPA004",
                statusCode: 500);

            if (ex != null)
            {
                switch (ex)
                {
                    case UpdateCelebrityException:
                    case DeleteCelebrityException:
                    case FoundByIdException:
                        rc = Results.NotFound(ex.Message);
                        break;
                    case FileNotFoundException:
                        rc = Results.Problem(
                            title: "ASPA004/FileNotFound",
                            detail: ex.Message,
                            instance: app.Environment.EnvironmentName,
                            statusCode: 404);
                        break;
                    case BadHttpRequestException:
                        rc = Results.BadRequest(ex.Message);
                        break;
                    case SaveException:
                    case AddCelebrityException:
                        rc = Results.Problem(
                            title: $"ASPA004/{ex.GetType().Name}",
                            detail: ex.Message,
                            instance: app.Environment.EnvironmentName,
                            statusCode: 500);
                        break;
                    case ArgumentNullException:
                        rc = Results.Problem(
                            title: "ASPA004/Validation",
                            detail: ex.Message,
                            instance: app.Environment.EnvironmentName,
                            statusCode: 400);
                        break;
                }
            }
            return rc;
        });

        app.MapFallback((HttpContext ctx) =>
        {
            return Results.NotFound(new { error = $"path {ctx.Request.Path} not supported" });
        });

        app.Run();
    }
}

public class SurnameFilter : IEndpointFilter
{
    private readonly IRepository _repository;

    public SurnameFilter(IRepository repository)
    {
        _repository = repository;
    }

    public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        var celebrity = context.GetArgument<Celebrity>(0);
        if (celebrity == null)
        {
            throw new ArgumentNullException("Celebrity object is required");
        }

        if (string.IsNullOrEmpty(celebrity.Surname) || celebrity.Surname.Length < 2)
        {
            throw new BadHttpRequestException("Surname is required and must be at least 2 characters long");
        }

        var existingCelebrities = _repository.getCelebritiesBySurname(celebrity.Surname);
        if (existingCelebrities.Length > 0)
        {
            throw new BadHttpRequestException($"Celebrity with surname '{celebrity.Surname}' already exists");
        }

        return await next(context);
    }
}

public class PhotoExistFilter : IEndpointFilter
{
    private readonly IRepository _repository;

    public PhotoExistFilter(IRepository repository)
    {
        _repository = repository;
    }

    public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        var celebrity = context.GetArgument<Celebrity>(0);

        if (!string.IsNullOrEmpty(celebrity.PhotoPath))
        {
            var fileName = Path.GetFileName(celebrity.PhotoPath);
            var fullPath = Path.Combine(_repository.BasePath, fileName);
            if (!File.Exists(fullPath))
            {
                context.HttpContext.Response.Headers.Append("X-Celebrity", $"NotFound={fileName}");
            }
        }

        return await next(context);
    }
}

public class UpdateFilter : IEndpointFilter
{
    private readonly IRepository _repository;

    public UpdateFilter(IRepository repository)
    {
        _repository = repository;
    }

    public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        var id = context.GetArgument<int>(0);
        var celebrity = context.GetArgument<Celebrity>(1);

        var existingCelebrity = _repository.getCelebrityById(id);
        if (existingCelebrity == null)
        {
            throw new BadHttpRequestException($"Celebrity with ID {id} not found");
        }

        if (!string.IsNullOrEmpty(celebrity.Surname) && celebrity.Surname.Length < 2)
        {
            throw new BadHttpRequestException("Surname must be at least 2 characters long");
        }

        return await next(context);
    }
}

public class DeleteFilter : IEndpointFilter
{
    private readonly IRepository _repository;

    public DeleteFilter(IRepository repository)
    {
        _repository = repository;
    }

    public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        var id = context.GetArgument<int>(0);

        var existingCelebrity = _repository.getCelebrityById(id);
        if (existingCelebrity == null)
        {
            throw new BadHttpRequestException($"Celebrity with ID {id} not found");
        }

        return await next(context);
    }
}