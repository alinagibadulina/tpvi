﻿using DAL_Celebrity_MSSQL.Models;
using Microsoft.EntityFrameworkCore;

namespace DAL_Celebrity_MSSQL.Data
{
    public class Context:DbContext
    {
        public string? ConnectionString { get; private set; } = null;

        public Context(string connectionString):base()
        {
            this.ConnectionString = connectionString;
            //this.Database.EnsureDeleted;
            //this.Database.EnsureCreated;
        }

        public Context() : base()
        {
            //this.Database.EnsureDeleted;
            //this.Database.EnsureCreated;
        }

        public DbSet<Celebrity> Celebrities { get; set; }
        public DbSet<Lifeevent> Lifeevents { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseNpgsql(this.ConnectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Celebrity>(entity =>
            {
                entity.ToTable("celebrities");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).HasColumnName("id").IsRequired();
                entity.Property(e => e.FullName).HasColumnName("fullname").IsRequired().HasMaxLength(50);
                entity.Property(e => e.Nationality).HasColumnName("nationality").IsRequired().HasMaxLength(2);
                entity.Property(e => e.ReqPhotoPath).HasColumnName("reqphotopath").HasMaxLength(200);
            });

            modelBuilder.Entity<Lifeevent>(entity =>
            {
                entity.ToTable("lifeevents");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).HasColumnName("id").IsRequired();
                entity.Property(e => e.CelebrityId).HasColumnName("celebrityid").IsRequired();
                entity.Property(e => e.Date)
                      .HasColumnName("date")
                      .HasColumnType("timestamp without time zone");

                entity.Property(e => e.Description).HasColumnName("description").HasMaxLength(256);
                entity.Property(e => e.ReqPhotoPath).HasColumnName("reqphotopath").HasMaxLength(256);

                entity.HasOne<Celebrity>()
                      .WithMany()
                      .HasForeignKey(e => e.CelebrityId);
            });

            base.OnModelCreating(modelBuilder);
        }

    }
}