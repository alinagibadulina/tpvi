﻿namespace Lab7.Configuration
{
    public class CelebritiesConfig
    {

        public string PhotosFolder {  get; set; }

        public string PhotosRequestPath { get; set; }
        public string ConnectionString { get; set; }
    }
}
