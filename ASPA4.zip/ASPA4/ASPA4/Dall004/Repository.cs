﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;

namespace Dall004
{
    public class Repository:IRepository
    {

        private int _changesCount = 0;
        public static string JSONFileName { get; set; }

        public string BasePath { get; }

        private Celebrity[] _celebrities;

        public Repository(string basePath)
        {

            BasePath = Path.Combine(@"C:\УНИВЕР\ASPA4\ASPA4\Dall004", basePath);
            string jsonPath = Path.Combine(BasePath, JSONFileName);
            if (File.Exists(jsonPath))
            {
                string jsonData = File.ReadAllText(jsonPath);
                _celebrities = JsonSerializer.Deserialize<Celebrity[]>(jsonData) ?? Array.Empty<Celebrity>();
            }
            else
            {
                _celebrities = Array.Empty<Celebrity>();
            }
        }
        public Celebrity? getCelebrityById(int id) => _celebrities.FirstOrDefault(c => c.Id == id);

        public Celebrity[] getAllCelebrities() => _celebrities;

        public Celebrity[] getCelebritiesBySurname(string surname) => _celebrities.Where(c => c.Surname == surname).ToArray();
        public string? getPhotoPathId(int id) => _celebrities.Where(c => c.Id == id).FirstOrDefault()?.PhotoPath;
        public void Dispose()
        {

        }
        public int? addCelebrity(Celebrity celebrity)
        {
            if (celebrity == null)
                return null;

            int newId = _celebrities.Length > 0 ? _celebrities.Max(c => c.Id) + 1 : 1;

            var newCelebrity = celebrity with { Id = newId }; // Создаем копию с новым Id
            _celebrities = _celebrities.Append(newCelebrity).ToArray();
            _changesCount++;
            return newId;
        }

        public bool delCelebrityById(int id)
        {
            int initialCount = _celebrities.Length;
            _celebrities = _celebrities.Where(c => c.Id != id).ToArray();

            if (_celebrities.Length < initialCount)
            {
                _changesCount++;
                return true;
            }
            return false;
        }

        public int? updCelebrityById(int id, Celebrity celebrity)
        {
            bool updated = false;
            _celebrities = _celebrities.Select(c =>
            {
                if (c.Id == id)
                {
                    updated = true;
                    return celebrity with { Id = id };
                }
                return c;
            }).ToArray();

            if (updated)
            {
                _changesCount++;
                return id;
            }
            return null;
        }

        public int SaveChanges()
        {
            string jsonPath = Path.Combine(BasePath, JSONFileName);
            if (!File.Exists(jsonPath))
            {
                throw new FileNotFoundException($"Could not find file {jsonPath}.");
            }
            string jsonData = JsonSerializer.Serialize(_celebrities, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(jsonPath, jsonData);

            int savedChanges = _changesCount;
            _changesCount = 0;
            if (savedChanges <= 0)
            {
                return -1;
            }
            return savedChanges;
        }
    
}
}
