// Функция для получения случайного числа в заданном диапазоне
function getRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Функция для создания массива случайных чисел
function createRandomArray(length, min, max) {
    return Array.from({ length }, () => getRandomNumber(min, max));
}

// Функция для вывода массива
function printArray(arr, message = "") {
    if (message) console.log(message);
    console.log(arr.join(", "));
}

// Создаем массив
const length = 10;
const minValue = 1;
const maxValue = 100;
const numbers = createRandomArray(length, minValue, maxValue);

// Выводим исходный массив
printArray(numbers, "Исходный массив:");

// Находим сумму элементов с четными индексами
const sumEvenIndexes = numbers.reduce((sum, num, index) => {
    return index % 2 === 0 ? sum + num : sum;
}, 0);

console.log(`\nСумма элементов с четными индексами: ${sumEvenIndexes}`); 