﻿

namespace DAL_Celebrity_MSSQL
{
    public class CelebrityTitles
    {
        public string Head { get; } = "Celebrities Dictionary Internet Service";
        public string Title { get; } = "Celebrities";
        public string CopyRight { get; } = "@Copyright BSTU";
    }
}
