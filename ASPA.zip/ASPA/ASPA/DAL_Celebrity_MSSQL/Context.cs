﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace DAL_Celebrity_MSSQL
{
    public class Context : DbContext
    {
        public string? ConnectionString { get; private set; } = null;
        public Context(string connextionString) : base()
        {
            ConnectionString = connextionString;
        }
        public Context() : base()
        {

        }

        public DbSet<Celebrity> Celebrities { get; set; }

        public DbSet<LifeEvent> LifeEvents { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (this.ConnectionString is null)
                this.ConnectionString = "Host=localhost;Port=5432;Database=Celebrity;Username=postgres;Password=1234";

            optionsBuilder.UseNpgsql(this.ConnectionString);
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Celebrity>(entity =>
            {
                entity.ToTable("celebrities");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).HasColumnName("id").IsRequired();
                entity.Property(e => e.FullName).HasColumnName("fullname").IsRequired().HasMaxLength(50);
                entity.Property(e => e.Nationality).HasColumnName("nationality").IsRequired().HasMaxLength(2);
                entity.Property(e => e.ReqPhotoPath).HasColumnName("reqphotopath").HasMaxLength(200);
            });

            modelBuilder.Entity<LifeEvent>(entity =>
            {
                entity.ToTable("lifeevents");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).HasColumnName("id").IsRequired();
                entity.Property(e => e.CelebrityId).HasColumnName("celebrityid").IsRequired();
                entity.Property(e => e.Date)
                      .HasColumnName("date")
                      .HasColumnType("timestamp without time zone");

                entity.Property(e => e.Description).HasColumnName("description").HasMaxLength(256);
                entity.Property(e => e.ReqPhotoPath).HasColumnName("reqphotopath").HasMaxLength(256);

                entity.HasOne<Celebrity>()
                      .WithMany()
                      .HasForeignKey(e => e.CelebrityId);
            });

            base.OnModelCreating(modelBuilder);
        }

    }
}